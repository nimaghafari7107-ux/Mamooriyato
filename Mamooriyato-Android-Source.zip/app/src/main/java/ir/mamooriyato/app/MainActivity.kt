package ir.mamooriyato.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

private const val ADMIN_UID = "SET_ADMIN_UID_AFTER_FIRST_LOGIN"
private val db get() = FirebaseFirestore.getInstance()
private val auth get() = FirebaseAuth.getInstance()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { MamooriyatoApp() } }
    }
}

data class Mission(val id: String = "", val title: String = "", val description: String = "",
                   val url: String = "", val reward: Long = 0, val active: Boolean = true)

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun MamooriyatoApp() {
    var user by remember { mutableStateOf(auth.currentUser) }
    var page by remember { mutableStateOf("missions") }
    var missions by remember { mutableStateOf(listOf<Mission>()) }
    var balance by remember { mutableLongStateOf(0L) }
    var message by remember { mutableStateOf("") }
    val uid = user?.uid
    val isAdmin = uid != null && uid == ADMIN_UID

    LaunchedEffect(uid) {
        if (uid != null) {
            db.collection("missions").whereEqualTo("active", true).addSnapshotListener { s, _ ->
                missions = s?.documents?.map { d -> Mission(d.id, d.getString("title") ?: "",
                    d.getString("description") ?: "", d.getString("url") ?: "",
                    d.getLong("reward") ?: 0L, d.getBoolean("active") ?: true) } ?: emptyList()
            }
            db.collection("wallets").document(uid).addSnapshotListener { s, _ ->
                balance = s?.getLong("balance") ?: 0L
            }
        }
    }

    if (user == null) {
        PhoneLogin { user = auth.currentUser }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("ماموریتو", fontWeight = FontWeight.Bold) },
                actions = { TextButton(onClick = { auth.signOut(); user = null }) { Text("خروج") } })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = page == "missions", onClick = { page = "missions" },
                    icon = { Icon(Icons.Default.List, null) }, label = { Text("ماموریت‌ها") })
                NavigationBarItem(selected = page == "wallet", onClick = { page = "wallet" },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("کیف پول") })
                if (isAdmin) NavigationBarItem(selected = page == "admin", onClick = { page = "admin" },
                    icon = { Icon(Icons.Default.AdminPanelSettings, null) }, label = { Text("مدیریت") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            when (page) {
                "wallet" -> WalletPage(balance) { amount, card ->
                    val u = auth.currentUser ?: return@WalletPage
                    if (amount < 100_000) message = "حداقل برداشت ۱۰۰٬۰۰۰ تومان است."
                    else if (amount > balance) message = "موجودی کافی نیست."
                    else db.collection("withdrawals").add(mapOf(
                        "uid" to u.uid, "amount" to amount, "cardNumber" to card,
                        "status" to "pending", "createdAt" to System.currentTimeMillis()
                    )).addOnSuccessListener { message = "درخواست برداشت ثبت شد؛ پرداخت پس از بررسی دستی انجام می‌شود." }
                }
                "admin" -> AdminPage { message = it }
                else -> MissionList(missions, isAdmin) { message = it }
            }
        }
    }
}

@Composable
fun PhoneLogin(onLoggedIn: () -> Unit) {
    val context = LocalContext.current
    var phone by remember { mutableStateOf("+98") }
    var code by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("شماره موبایل را با کد کشور وارد کنید.") }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("ماموریتو", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("ماموریت انجام بده، پاداش بگیر")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(phone, { phone = it }, label = { Text("شماره موبایل") }, modifier = Modifier.fillMaxWidth())
        verificationId?.let {
            OutlinedTextField(code, { code = it }, label = { Text("کد پیامک") }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(12.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            if (verificationId == null) {
                busy = true
                val options = PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(phone).setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                    .setActivity(context as ComponentActivity)
                    .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                            auth.signInWithCredential(credential).addOnSuccessListener { onLoggedIn() }
                                .addOnFailureListener { status = it.localizedMessage ?: "خطا در ورود" }
                            busy = false
                        }
                        override fun onVerificationFailed(e: FirebaseException) {
                            status = e.localizedMessage ?: "ارسال پیامک ناموفق بود"; busy = false
                        }
                        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                            verificationId = id; status = "کد ارسال شد."; busy = false
                        }
                    }).build()
                PhoneAuthProvider.verifyPhoneNumber(options)
            } else {
                val credential = PhoneAuthProvider.getCredential(verificationId!!, code)
                auth.signInWithCredential(credential).addOnSuccessListener { onLoggedIn() }
                    .addOnFailureListener { status = it.localizedMessage ?: "کد نامعتبر است" }
            }
        }) { Text(if (verificationId == null) "ارسال کد تأیید" else "ورود") }
        Text(status, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun MissionList(missions: List<Mission>, isAdmin: Boolean, notify: (String) -> Unit) {
    val context = LocalContext.current
    Text("ماموریت‌های فعال", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    if (missions.isEmpty()) Text("فعلاً مأموریت فعالی ثبت نشده است.", modifier = Modifier.padding(16.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(missions) { m ->
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(m.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(m.description)
                    Text("پاداش: ${m.reward} تومان", color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = {
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse(m.url))
                        try { context.startActivity(intent) } catch (_: Exception) { notify("لینک معتبر نیست.") }
                    }) { Text("باز کردن لینک") }
                    var proof by remember { mutableStateOf<android.net.Uri?>(null) }
                    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { proof = it }
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("انتخاب اسکرین‌شات و ارسال")
                    }
                    proof?.let { uri ->
                        Text("تصویر انتخاب شد.")
                        Button(onClick = {
                            val u = auth.currentUser ?: return@Button
                            val ref = FirebaseStorage.getInstance().reference.child("submissions/${u.uid}/${UUID.randomUUID()}.jpg")
                            ref.putFile(uri).continueWithTask { task ->
                                if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                                ref.downloadUrl
                            }.addOnSuccessListener { download ->
                                db.collection("submissions").add(mapOf(
                                    "uid" to u.uid, "missionId" to m.id, "missionTitle" to m.title,
                                    "reward" to m.reward, "imageUrl" to download.toString(),
                                    "status" to "pending", "createdAt" to System.currentTimeMillis()
                                )).addOnSuccessListener { notify("اسکرین‌شات ارسال شد و در انتظار بررسی است.") }
                                    .addOnFailureListener { notify("ثبت ارسال ناموفق بود.") }
                            }.addOnFailureListener { notify("آپلود تصویر ناموفق بود.") }
                        }) { Text("ثبت مدرک") }
                    }
                }
            }
        }
    }
}

@Composable
fun WalletPage(balance: Long, request: (Long, String) -> Unit) {
    var amount by remember { mutableStateOf("100000") }
    var card by remember { mutableStateOf("") }
    Text("کیف پول", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Card(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text("موجودی قابل برداشت")
            Text("$balance تومان", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
    OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("مبلغ برداشت (تومان)") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(card, { card = it }, label = { Text("شماره کارت ۱۶ رقمی") }, modifier = Modifier.fillMaxWidth())
    Button(onClick = { request(amount.toLongOrNull() ?: 0L, card) }, modifier = Modifier.fillMaxWidth()) { Text("ثبت درخواست برداشت") }
    Text("حداقل برداشت: ۱۰۰٬۰۰۰ تومان. پرداخت پس از بررسی، دستی انجام می‌شود.", modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun AdminPage(notify: (String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var reward by remember { mutableStateOf("") }
    var submissions by remember { mutableStateOf(listOf<Map<String, Any>>()) }

    LaunchedEffect(Unit) {
        db.collection("submissions").whereEqualTo("status", "pending").addSnapshotListener { s, _ ->
            submissions = s?.documents?.map { it.data.orEmpty() + ("docId" to it.id) } ?: emptyList()
        }
    }
    Text("پنل مدیریت", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("ثبت مأموریت جدید", fontWeight = FontWeight.Bold)
            OutlinedTextField(title, { title = it }, label = { Text("عنوان") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(desc, { desc = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(url, { url = it }, label = { Text("لینک مأموریت") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(reward, { reward = it.filter(Char::isDigit) }, label = { Text("پاداش (تومان)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (title.isBlank() || url.isBlank() || (reward.toLongOrNull() ?: 0L) <= 0) notify("عنوان، لینک و مبلغ معتبر لازم است.")
                else db.collection("missions").add(mapOf("title" to title, "description" to desc,
                    "url" to url, "reward" to reward.toLong(), "active" to true))
                    .addOnSuccessListener { title = ""; desc = ""; url = ""; reward = ""; notify("مأموریت ثبت شد.") }
                    .addOnFailureListener { notify("ثبت مأموریت ناموفق بود.") }
            }, modifier = Modifier.fillMaxWidth()) { Text("افزودن مأموریت") }
            Divider(Modifier.padding(vertical = 12.dp))
            Text("مدارک در انتظار بررسی", fontWeight = FontWeight.Bold)
        }
        items(submissions) { s ->
            val id = s["docId"] as? String ?: ""
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text(s["missionTitle"] as? String ?: "ماموریت")
                    Text("شناسه کاربر: ${s["uid"] ?: ""}")
                    AsyncImage(model = s["imageUrl"], contentDescription = "مدرک", modifier = Modifier.fillMaxWidth().height(180.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val uid = s["uid"] as? String ?: return@Button
                            val rewardValue = s["reward"] as? Long ?: 0L
                            val batch = db.batch()
                            val wallet = db.collection("wallets").document(uid)
                            batch.set(wallet, mapOf("balance" to com.google.firebase.firestore.FieldValue.increment(rewardValue)), com.google.firebase.firestore.SetOptions.merge())
                            batch.update(db.collection("submissions").document(id), "status", "approved")
                            batch.commit().addOnSuccessListener { notify("مدرک تأیید و پاداش ثبت شد.") }
                                .addOnFailureListener { notify("خطا در تأیید؛ دوباره بررسی کن.") }
                        }) { Text("تأیید و پرداخت پاداش") }
                        OutlinedButton(onClick = {
                            db.collection("submissions").document(id).update("status", "rejected")
                                .addOnSuccessListener { notify("مدرک رد شد.") }
                        }) { Text("رد") }
                    }
                }
            }
        }
    }
}
